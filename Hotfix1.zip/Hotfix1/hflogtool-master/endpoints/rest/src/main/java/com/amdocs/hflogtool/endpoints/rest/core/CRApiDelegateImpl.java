package com.amdocs.hflogtool.endpoints.rest.core;

import com.amdocs.hflogtool.api.CRApiDelegate;
import com.amdocs.hflogtool.model.CR;
import com.amdocs.hflogtool.services.api.CRService;
import com.amdocs.hflogtool.endpoints.rest.core.mapper.CRMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class CRApiDelegateImpl implements CRApiDelegate {

    private final CRService crService;

    @Autowired
    public CRApiDelegateImpl(CRService crService) {
        this.crService = crService;
    }

    @Override
    public ResponseEntity<Void> addCR(CR cr) {
        crService.save(CRMapper.INSTANCE.mapCRToCREntity(cr));
        return null;
    }
    @Override
    public ResponseEntity<List<CR>> findAllCR() {
       return (ResponseEntity<List<CR>>) crService.findAll();

    }

    @Override
    public ResponseEntity<CR> findCRByID(String id) {
        return new ResponseEntity<>(CRMapper.INSTANCE.mapCREntityToCR(crService.findById(id)),HttpStatus.ACCEPTED);
    }

    @Override
    public ResponseEntity<Void> updateCR(String id, CR cr){
       CR oldCR=CRMapper.INSTANCE.mapCREntityToCR(crService.findById(id));
        String jsonString="";
        List<String> gerritList=new ArrayList<>();
        try {
            ObjectMapper mapper = new ObjectMapper();
             jsonString = mapper.writeValueAsString(cr);
        }
        catch(JsonProcessingException e)
        {
            System.out.println(e);
;        }
        JSONObject json=new JSONObject(jsonString);
        Iterator<String> it=json.keySet().iterator();
        while(it.hasNext())
        {
            String key=it.next();
            switch(key){
                case "title":if(json.get(key)!=JSONObject.NULL)

                             oldCR.setTitle((String) json.get(key));
                break;
                case "owner":if(json.get(key)!=JSONObject.NULL)

                                 oldCR.setOwner((String) json.get(key));
                break;
                case "id":if(json.get(key)!=JSONObject.NULL)

                          oldCR.setId((String) json.get(key));
                break;
                case "productName":if(json.get(key)!=JSONObject.NULL)

                                   oldCR.setProductName((String) json.get(key));
                break;
                case "releaseTag":if(json.get(key)!=JSONObject.NULL)

                                      oldCR.setReleaseTag((String) json.get(key));
                break;
                case "type":if(json.get(key)!=JSONObject.NULL)

                            oldCR.setType((String) json.get(key));
                break;
                case "reportingRelease":if(json.get(key)!=JSONObject.NULL)

                                        oldCR.setReportingRelease((String) json.get(key));
                break;
                case "rolledUpToRelease":if(json.get(key)!=JSONObject.NULL)

                                         oldCR.setRolledUpToRelease((String) json.get(key));
                break;
                case "rolledDownFromRelease":if(json.get(key)!=JSONObject.NULL)

                                                 oldCR.setRolledDownFromRelease((String) json.get(key));

                break;
                case "comments":if(json.get(key)!=JSONObject.NULL)

                                 oldCR.setComments((String) json.get(key));
                case "gerritIds":if(json.get(key)!=JSONObject.NULL){
                    JSONArray jarray= json.getJSONArray("gerritIds");
                    for(int i=0;i<jarray.length();i++){
                        String s=jarray.getString(i);
                        gerritList.add(s);


                    }
                       oldCR.setGerritIds(gerritList);
                }


            } }
        crService.save(CRMapper.INSTANCE.mapCRToCREntity(oldCR));
        return null;
    }

    @Override
    public ResponseEntity<Void> deleteCR(String id) {
        crService.delete(id);
        return null;
    }

}
